# JARVIS Starter 0.1

A free, static browser prototype for starting a personal assistant project.

## What it does
- Futuristic mobile-friendly interface
- Browser speech output (where supported)
- Experimental browser speech recognition (support varies, especially on iOS)
- Built-in demo commands
- Local task list saved in this browser using localStorage

## What it does NOT do yet
- It is not a full AI model and does not answer arbitrary questions intelligently
- It cannot control the phone or computer
- It does not run tasks while the browser is closed
- It does not sync memory between devices
- It does not send notifications or connect to external accounts

## Open on iPhone
For the best chance of microphone support, host this page on an HTTPS website rather than opening index.html directly from Files. One free route is GitHub Pages:
1. Create/sign in to a GitHub account in Safari.
2. Create a new public repository named `jarvis-starter`.
3. Upload `index.html` from this folder.
4. In the repository, open Settings -> Pages.
5. Under Build and deployment, choose deployment from a branch, select `main` and `/ (root)`, then Save.
6. Wait for the Pages URL to appear and open it on your iPhone.

GitHub's menus can change. This is a static prototype and contains no secret API key.

## Next stage
Add a server-side AI connection (never expose API keys in a public static webpage), then tools with explicit permissions, durable memory, scheduled background tasks, and notifications. A free budget may limit the AI usage and hosting options.
